import subprocess
import sys
import json
from http.server import HTTPServer, BaseHTTPRequestHandler

class ScanHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/scan':
            # Exécute scanner.py et capture sa sortie JSON
            try:
                result = subprocess.run([sys.executable, 'scanner.py'], capture_output=True, text=True, timeout=60)
                # On retourne les résultats bruts pour l'instant
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.wfile.write(b"Scan termine. Verifiez votre dashboard pour les resultats.")
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(f"Erreur lors du scan : {e}".encode())
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        # Désactive les logs
        pass

if __name__ == '__main__':
    server = HTTPServer(('localhost', 8888), ScanHandler)
    print("Serveur local demarre sur http://localhost:8888")
    print("Pour lancer un scan, utilisez le bouton dans le dashboard")
    server.serve_forever() 