import socket
import platform
import subprocess
import json
import requests
import sys
import os
from datetime import datetime

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def run_system_command(command):
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace"
    )


# Configuration
SERVER_URL = os.environ.get("SENTINELX_SERVER_URL", "http://127.0.0.1:8000/security/api/receive-scan/")
USERNAME = sys.argv[1] if len(sys.argv) > 1 else input("Nom d'utilisateur SentinelX : ")

if len(sys.argv) == 1:
    print(f"\nAutorisez-vous SentinelX à analyser votre machine ? (y/n)")
    if input().lower() != 'y':
        print("Scan annulé.")
        exit()
else:
    print("Scan automatique autorisé.")

hostname = socket.gethostname()
ip = socket.gethostbyname(hostname)
os_info = platform.system() + " " + platform.release()

print(f"\nAnalyse de {hostname} ({ip})...")

# Liste pour stocker les résultats de sécurité (True = sécurisé / OK, False = problème)
security_results = []
security_details = []

# ==================== SCANNER 1: PARE-FEU ====================
firewall_status = "Inconnu"
if platform.system() == "Windows":
    try:
        result = run_system_command(["netsh", "advfirewall", "show", "allprofiles"])
        firewall_status = "Actif" if "État du profil : On" in result.stdout else "Inactif"
    except:
        firewall_status = "Indisponible"
else:
    firewall_status = "Non vérifié"

firewall_ok = (firewall_status == "Actif")
security_results.append(firewall_ok)
security_details.append({"nom": "Pare-feu", "ok": firewall_ok, "statut": firewall_status})

# ==================== SCANNER 2: PROCESSUS SENSIBLES ====================
sensitive_processes = []
sensitive_names = ["nmap", "wireshark", "metasploit", "burpsuite", "nikto", "sqlmap"]
try:
    result = run_system_command(["tasklist"])
    for proc in sensitive_names:
        if proc.lower() in result.stdout.lower():
            sensitive_processes.append(proc)
except:
    sensitive_processes = []

process_ok = (len(sensitive_processes) == 0)
security_results.append(process_ok)
security_details.append({"nom": "Processus sensibles", "ok": process_ok, "statut": sensitive_processes if sensitive_processes else "Aucun"})

# ==================== SCANNER 3: CONNEXIONS ACTIVES ====================
active_ports = []
try:
    result = run_system_command(["netstat", "-an"])
    for line in result.stdout.splitlines():
        if "LISTENING" in line or "LISTEN" in line:
            parts = line.split()
            if len(parts) > 1:
                local_addr = parts[1]
                if ":" in local_addr:
                    port = local_addr.split(":")[-1]
                    if port.isdigit():
                        active_ports.append(int(port))
    active_ports = list(set(active_ports))[:10]
except:
    active_ports = []

active_ports_ok = (len(active_ports) == 0)
security_results.append(active_ports_ok)
security_details.append({"nom": "Connexions actives", "ok": active_ports_ok, "statut": active_ports[:5] if active_ports else "Aucune"})

# ==================== SCANNER 4: LOGICIELS VULNÉRABLES ====================
vulnerable_software = []
vulnerable_names = ["java", "flash", "vlc", "winrar", "7zip", "firefox", "chrome", "adobe reader"]
try:
    result = run_system_command(["wmic", "product", "get", "name"])
    for soft in vulnerable_names:
        if soft.lower() in result.stdout.lower():
            vulnerable_software.append(soft)
except:
    vulnerable_software = []

vulnerable_ok = (len(vulnerable_software) == 0)
security_results.append(vulnerable_ok)
security_details.append({"nom": "Logiciels vulnérables", "ok": vulnerable_ok, "statut": vulnerable_software if vulnerable_software else "Aucun"})

# ==================== SCANNER 5: SERVICES CRITIQUES ====================
critical_services = []
critical_names = ["Rdp", "SMB", "Telnet", "RemoteRegistry", "WSearch"]
try:
    result = run_system_command(["sc", "query"])
    for service in critical_names:
        if service.lower() in result.stdout.lower():
            critical_services.append(service)
except:
    critical_services = []

critical_ok = (len(critical_services) == 0)
security_results.append(critical_ok)
security_details.append({"nom": "Services critiques", "ok": critical_ok, "statut": critical_services if critical_services else "Aucun"})

# ==================== SCANNER 6: UTILISATEURS ADMINISTRATEURS ====================
admin_count = 0
try:
    result = run_system_command(["net", "localgroup", "Administrateurs"])
    lines = result.stdout.splitlines()
    for line in lines:
        if "----" in line or "commande" in line.lower():
            continue
        if line.strip() and not line.startswith("Alis"):
            admin_count += 1
    admin_count = max(0, admin_count - 4)
except:
    admin_count = 0

admin_ok = (admin_count <= 2)
security_results.append(admin_ok)
security_details.append({"nom": "Comptes administrateurs", "ok": admin_ok, "statut": f"{admin_count} comptes"})

# ==================== SCANNER 7: SERVICES AU DÉMARRAGE ====================
startup_services = []
try:
    result = run_system_command(["wmic", "startup", "get", "caption"])
    for line in result.stdout.splitlines():
        if line.strip() and not "Caption" in line:
            startup_services.append(line.strip())
    startup_services = startup_services[:10]
except:
    startup_services = []

startup_ok = (len(startup_services) == 0)
security_results.append(startup_ok)
security_details.append({"nom": "Services au démarrage", "ok": startup_ok, "statut": startup_services[:3] if startup_services else "Aucun"})

# ==================== SCANNER 8: ANTI-VIRUS ====================
antivirus_detected = []
try:
    result = run_system_command(["wmic", "/namespace:\\\\root\\SecurityCenter2", "path", "AntivirusProduct", "get", "displayName"])
    for line in result.stdout.splitlines():
        if line.strip() and not "displayName" in line:
            antivirus_detected.append(line.strip())
except:
    try:
        result = run_system_command(["powershell", "Get-MpComputerStatus"])
        if "True" in result.stdout:
            antivirus_detected.append("Windows Defender")
    except:
        antivirus_detected = []

antivirus_ok = (len(antivirus_detected) > 0)
security_results.append(antivirus_ok)
security_details.append({"nom": "Anti-virus", "ok": antivirus_ok, "statut": antivirus_detected if antivirus_detected else "Aucun"})

# ==================== SCAN DES PORTS (20 ports) ====================
ports = [
    (20, "FTP-DATA", "Moyen"),
    (21, "FTP", "Élevé"),
    (22, "SSH", "Moyen"),
    (23, "Telnet", "Élevé"),
    (25, "SMTP", "Moyen"),
    (53, "DNS", "Faible"),
    (80, "HTTP", "Faible"),
    (110, "POP3", "Moyen"),
    (135, "RPC", "Moyen"),
    (139, "NetBIOS", "Moyen"),
    (143, "IMAP", "Moyen"),
    (443, "HTTPS", "Faible"),
    (445, "SMB", "Élevé"),
    (993, "IMAPS", "Faible"),
    (995, "POP3S", "Faible"),
    (1433, "MSSQL", "Élevé"),
    (3306, "MySQL", "Moyen"),
    (3389, "RDP", "Élevé"),
    (5432, "PostgreSQL", "Moyen"),
    (8080, "HTTP-Alt", "Faible")
]

results = []
alertes = []
port_results = []

for port, service, risque in ports:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((ip, port))
        if result == 0:
            status = "ouvert"
            alertes.append(f"Port {service} ({port}) ouvert - Risque {risque}")
            port_ok = False
        else:
            status = "fermé"
            port_ok = True
        sock.close()
    except:
        status = "erreur"
        port_ok = False
    
    port_results.append(port_ok)
    security_results.append(port_ok)
    security_details.append({"nom": f"Port {service} ({port})", "ok": port_ok, "statut": status, "risque": risque})
    
    results.append({
        "port": port,
        "service": service,
        "status": status,
        "risk": risque
    })

# ==================== CALCUL DU SCORE (POURCENTAGE) ====================
total_checks = len(security_results)
secure_count = sum(1 for r in security_results if r)
score = int((secure_count / total_checks) * 100) if total_checks > 0 else 0

print(f"Score de sécurité : {score}/100 ({secure_count}/{total_checks} éléments sécurisés)")
print(f"Pare-feu : {firewall_status}")
print(f"Processus sensibles : {sensitive_processes if sensitive_processes else 'Aucun'}")
print(f"Logiciels vulnérables : {vulnerable_software if vulnerable_software else 'Aucun'}")
print(f"Services critiques : {critical_services if critical_services else 'Aucun'}")
print(f"Administrateurs : {admin_count}")
print(f"Anti-virus : {antivirus_detected if antivirus_detected else 'Aucun détecté'}")

# Affichage des ports ouverts
open_ports_list = [p for p in results if p["status"] == "ouvert"]
if open_ports_list:
    print(f"Ports ouverts : {len(open_ports_list)}")
else:
    print("Ports ouverts : Aucun")

# ==================== GÉNÉRATION DES ALERTES ====================
if firewall_status != "Actif":
    alertes.append(f"Pare-feu : {firewall_status} - Risque potentiel")
if sensitive_processes:
    alertes.append(f"Processus sensibles détectés : {', '.join(sensitive_processes)}")
if active_ports:
    alertes.append(f"Connexions actives inattendues : {active_ports[:5]}")
if vulnerable_software:
    alertes.append(f"Logiciels vulnérables détectés : {', '.join(vulnerable_software)}")
if critical_services:
    alertes.append(f"Services critiques actifs : {', '.join(critical_services)}")
if admin_count > 2:
    alertes.append(f"Nombre d'administrateurs élevé : {admin_count} comptes")
if startup_services:
    alertes.append(f"Services au démarrage suspect : {', '.join(startup_services[:3])}")
if not antivirus_detected:
    alertes.append("Aucun antivirus détecté - Risque élevé")

# Envoi à Django
data = {
    "username": USERNAME,
    "hostname": hostname,
    "ip": ip,
    "os": os_info,
    "date": datetime.now().isoformat(),
    "ports": results,
    "alertes": alertes,
    "score": score,
    "firewall": firewall_status,
    "sensitive_processes": sensitive_processes,
    "active_ports": active_ports[:5],
    "vulnerable_software": vulnerable_software,
    "critical_services": critical_services,
    "admin_count": admin_count,
    "startup_services": startup_services[:5],
    "antivirus_detected": antivirus_detected
}

try:
    response = requests.post(SERVER_URL, json=data)
    print("\n✅ Données envoyées à SentinelX")
    print("Résultat :", response.json())
except Exception as e:
    print("\n❌ Erreur d'envoi :", e) 
