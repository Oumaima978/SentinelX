from django.urls import path
from . import views
from . import api_views

urlpatterns = [
    path('add-machine/', views.add_machine, name='add_machine'),
    path('edit-machine/<int:machine_id>/', views.edit_machine, name='edit_machine'),
    path('delete-machine/<int:machine_id>/', views.delete_machine, name='delete_machine'),
    path('api/receive-scan/', api_views.receive_scan, name='receive_scan'),
    path('request-scan/', views.request_scan, name='request_scan'),
    path('approve-scan/<int:request_id>/', views.approve_scan, name='approve_scan'),
    path('reject-scan/<int:request_id>/', views.reject_scan, name='reject_scan'),
    path('run-scan-instruction/', views.run_scan_instruction, name='run_scan_instruction'),
    path('run-scan-ajax/', views.run_scan_ajax, name='run_scan_ajax'),
    path('scan-history/', views.scan_history, name='scan_history'),
    path('delete-scan/<int:scan_id>/', views.delete_scan, name='delete_scan'),
    path('scan-detail/<int:scan_id>/', views.view_scan_detail, name='scan_detail'),
    # CRUD Incidents
    path('incidents/', views.incident_list, name='incident_list'),
    path('incidents/create/', views.incident_create, name='incident_create'),
    path('incidents/update/<int:pk>/', views.incident_update, name='incident_update'),
    path('incidents/delete/<int:pk>/', views.incident_delete, name='incident_delete'),
    path('get-last-scan/', views.get_last_scan, name='get_last_scan'),
    # Analyst : arborescence utilisateurs
    path('api/users/', views.get_users_list, name='get_users_list'),
    path('api/users/<int:user_id>/machines/', views.get_user_machines, name='get_user_machines'),
    path('api/machines/<int:machine_id>/scans/', views.get_machine_scans, name='get_machine_scans'),
        # Pages d'aide
    path('help/score/', views.help_score, name='help_score'),
    path('help/elements/', views.help_elements, name='help_elements'), 
] 
