from django.db import models
from django.contrib.auth.models import User

class Machine(models.Model):
    name = models.CharField(max_length=100)
    ip_address = models.GenericIPAddressField()
    os = models.CharField(max_length=100)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.name 
    
class Scan(models.Model):
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE)
    date_scan = models.DateTimeField(auto_now_add=True)
    resultat = models.TextField()
    score = models.IntegerField()

    def __str__(self):
        return f"{self.machine.name} - {self.date_scan}"

class Port(models.Model):
    numero = models.IntegerField()
    service = models.CharField(max_length=50)
    status = models.CharField(max_length=20)
    risk_level = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.service} ({self.numero})"

class Alert(models.Model):
    message = models.CharField(max_length=255)
    severity = models.CharField(max_length=20)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.message

class Incident(models.Model):
    STATUS_CHOICES = [
        ('open', 'Ouvert'),
        ('in_progress', 'En cours'),
        ('resolved', 'Résolu'),
        ('closed', 'Fermé'),
    ]
    title = models.CharField(max_length=200)
    description = models.TextField()
    commentaire = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='incidents')
    related_scan = models.ForeignKey(Scan, on_delete=models.SET_NULL, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} - {self.get_status_display()}"
    
class ScanRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'En attente'),
        ('approved', 'Approuvé'),
        ('rejected', 'Refusé'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.machine.name} - {self.status}" 