from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User
from security.models import Machine, Scan, Port, Alert, Incident
import json

@csrf_exempt
def receive_scan(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            username = data.get('username')
            user = User.objects.get(username=username)
            
            machine, created = Machine.objects.get_or_create(
                owner=user,
                name=data.get('hostname'),
                defaults={
                    'ip_address': data.get('ip'),
                    'os': data.get('os')
                }
            )
            
            # Créer le scan avec TOUTES les nouvelles données
            scan = Scan.objects.create(
                machine=machine,
                resultat=json.dumps({
                    'ports': data.get('ports', []),
                    'firewall': data.get('firewall'),
                    'sensitive_processes': data.get('sensitive_processes', []),
                    'active_ports': data.get('active_ports', []),
                    # Nouveaux scanners
                    'vulnerable_software': data.get('vulnerable_software', []),
                    'critical_services': data.get('critical_services', []),
                    'admin_count': data.get('admin_count', 0),
                    'startup_services': data.get('startup_services', []),
                    'antivirus_detected': data.get('antivirus_detected', [])
                }),
                score=data.get('score', 0)
            )
            
            # Ajouter les ports
            for port_data in data.get('ports', []):
                Port.objects.create(
                    numero=port_data['port'],
                    service=port_data['service'],
                    status=port_data['status'],
                    risk_level=port_data['risk']
                )
            
            # Ajouter les alertes
            for alert_msg in data.get('alertes', []):
                Alert.objects.create(
                    message=alert_msg,
                    severity='Moyen' if 'ouvert' in alert_msg or 'Pare-feu' in alert_msg else 'Info'
                )
            
            # ==================== CRÉATION AUTOMATIQUE D'INCIDENTS ====================
            incidents_created = []
            
            # 1. Ports ouverts
            for port_data in data.get('ports', []):
                if port_data.get('status') == 'ouvert':
                    title = f"Port {port_data['service']} ({port_data['port']}) ouvert"
                    description = f"Le scan du {scan.date_scan} a détecté le port {port_data['service']} ({port_data['port']}) ouvert. Risque : {port_data['risk']}."
                    incident, created = Incident.objects.get_or_create(
                        title=title,
                        defaults={
                            'description': description,
                            'status': 'open',
                            'created_by': user,
                            'related_scan': scan
                        }
                    )
                    if created:
                        incidents_created.append(title)
            
            # 2. Processus sensibles
            sensitive_procs = data.get('sensitive_processes', [])
            if sensitive_procs:
                title = "Processus sensibles détectés"
                description = f"Le scan du {scan.date_scan} a détecté des processus sensibles : {', '.join(sensitive_procs)}."
                incident, created = Incident.objects.get_or_create(
                    title=title,
                    defaults={
                        'description': description,
                        'status': 'open',
                        'created_by': user,
                        'related_scan': scan
                    }
                )
                if created:
                    incidents_created.append(title)
            
            # 3. Pare-feu inactif
            if data.get('firewall') != 'Actif':
                title = f"Pare-feu {data.get('firewall')}"
                description = f"Le scan du {scan.date_scan} a détecté que le pare-feu est {data.get('firewall')}. Risque potentiel."
                incident, created = Incident.objects.get_or_create(
                    title=title,
                    defaults={
                        'description': description,
                        'status': 'open',
                        'created_by': user,
                        'related_scan': scan
                    }
                )
                if created:
                    incidents_created.append(title)
            
            # 4. Logiciels vulnérables
            vulnerable_software = data.get('vulnerable_software', [])
            if vulnerable_software:
                title = "Logiciels vulnérables détectés"
                description = f"Le scan du {scan.date_scan} a détecté des logiciels vulnérables : {', '.join(vulnerable_software)}."
                incident, created = Incident.objects.get_or_create(
                    title=title,
                    defaults={
                        'description': description,
                        'status': 'open',
                        'created_by': user,
                        'related_scan': scan
                    }
                )
                if created:
                    incidents_created.append(title)
            
            # 5. Services critiques actifs
            critical_services = data.get('critical_services', [])
            if critical_services:
                title = "Services critiques actifs"
                description = f"Le scan du {scan.date_scan} a détecté des services critiques actifs : {', '.join(critical_services)}."
                incident, created = Incident.objects.get_or_create(
                    title=title,
                    defaults={
                        'description': description,
                        'status': 'open',
                        'created_by': user,
                        'related_scan': scan
                    }
                )
                if created:
                    incidents_created.append(title)
            
            # 6. Trop d'administrateurs
            admin_count = data.get('admin_count', 0)
            if admin_count > 2:
                title = "Nombre élevé d'administrateurs"
                description = f"Le scan du {scan.date_scan} a détecté {admin_count} comptes administrateurs sur la machine."
                incident, created = Incident.objects.get_or_create(
                    title=title,
                    defaults={
                        'description': description,
                        'status': 'open',
                        'created_by': user,
                        'related_scan': scan
                    }
                )
                if created:
                    incidents_created.append(title)
            
            # 7. Absence d'antivirus
            antivirus_detected = data.get('antivirus_detected', [])
            if not antivirus_detected:
                title = "Aucun antivirus détecté"
                description = f"Le scan du {scan.date_scan} n'a détecté aucun antivirus sur la machine. Risque élevé."
                incident, created = Incident.objects.get_or_create(
                    title=title,
                    defaults={
                        'description': description,
                        'status': 'open',
                        'created_by': user,
                        'related_scan': scan
                    }
                )
                if created:
                    incidents_created.append(title)
            
            return JsonResponse({
                'status': 'ok', 
                'scan_id': scan.id,
                'incidents_created': incidents_created
            })
        
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    
    return JsonResponse({'status': 'error'}, status=405) 