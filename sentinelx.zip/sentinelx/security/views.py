from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import JsonResponse
from .forms import MachineForm, IncidentUserForm, IncidentAnalystForm
from .models import ScanRequest, Machine, Scan, Incident
import subprocess
import sys
import json
import os


def _scan_result_payload(scan):
    try:
        resultat = json.loads(scan.resultat) if isinstance(scan.resultat, str) else (scan.resultat or {})
    except json.JSONDecodeError:
        resultat = {}

    return {
        'id': scan.id,
        'date_scan': scan.date_scan.strftime('%d/%m/%Y %H:%M'),
        'machine': {
            'name': scan.machine.name,
            'ip_address': scan.machine.ip_address,
            'os': scan.machine.os,
            'owner': scan.machine.owner.username,
        },
        'score': scan.score,
        'resultat': {
            'firewall': resultat.get('firewall', 'Non disponible'),
            'sensitive_processes': resultat.get('sensitive_processes', []),
            'active_ports': resultat.get('active_ports', []),
            'vulnerable_software': resultat.get('vulnerable_software', []),
            'critical_services': resultat.get('critical_services', []),
            'admin_count': resultat.get('admin_count', 0),
            'startup_services': resultat.get('startup_services', []),
            'antivirus_detected': resultat.get('antivirus_detected', []),
            'ports': resultat.get('ports', []),
        }
    }

@login_required
def add_machine(request):
    if request.method == 'POST':
        form = MachineForm(request.POST)
        if form.is_valid():
            machine = form.save(commit=False)
            machine.owner = request.user
            machine.save()
            return redirect('dashboard')
    else:
        form = MachineForm()
    machines = Machine.objects.filter(owner=request.user).order_by('name')
    return render(request, 'add_machine.html', {'form': form, 'machines': machines})

@login_required
def edit_machine(request, machine_id):
    machine = get_object_or_404(Machine, id=machine_id, owner=request.user)
    if request.method == 'POST':
        form = MachineForm(request.POST, instance=machine)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    else:
        form = MachineForm(instance=machine)
    return render(request, 'edit_machine.html', {'form': form, 'machine': machine})

@login_required
def delete_machine(request, machine_id):
    machine = get_object_or_404(Machine, id=machine_id, owner=request.user)
    if request.method == 'POST':
        machine.delete()
        return redirect('dashboard')
    return render(request, 'delete_machine.html', {'machine': machine})

@login_required
def request_scan(request):
    if request.method == 'POST':
        machine_id = request.POST.get('machine_id')
        machine = Machine.objects.get(id=machine_id, owner=request.user)
        ScanRequest.objects.create(
            user=request.user,
            machine=machine,
            status='pending'
        )
        return redirect('dashboard')
    
    machines = Machine.objects.filter(owner=request.user)
    return render(request, 'request_scan.html', {'machines': machines})

@login_required
def approve_scan(request, request_id):
    scan_request = ScanRequest.objects.get(id=request_id)
    if request.user.profile.role == 'analyst':
        scan_request.status = 'approved'
        scan_request.save()
    return redirect('dashboard')

@login_required
def reject_scan(request, request_id):
    scan_request = ScanRequest.objects.get(id=request_id)
    if request.user.profile.role == 'analyst':
        scan_request.status = 'rejected'
        scan_request.save()
    return redirect('dashboard')

@login_required
def run_scan_instruction(request):
    return render(request, 'run_scan_instruction.html')

@login_required
def run_scan_ajax(request):
    if request.method == 'POST':
        try:
            body = json.loads(request.body)
            request_id = body.get('request_id')
            previous_scan_id = Scan.objects.filter(machine__owner=request.user).order_by('-id').values_list('id', flat=True).first() or 0

            env = os.environ.copy()
            env['SENTINELX_SERVER_URL'] = request.build_absolute_uri('/security/api/receive-scan/')
            env['PYTHONIOENCODING'] = 'utf-8'
            result = subprocess.run(
                [sys.executable, 'scanner.py', request.user.username],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=120,
                env=env
            )

            output = (result.stdout or '') + (('\n' + result.stderr) if result.stderr else '')
            scan_failed = (
                result.returncode != 0
                or "Erreur d'envoi" in output
                or "status': 'error'" in output
                or '"status": "error"' in output
            )
            if scan_failed:
                return JsonResponse({
                    'status': 'error',
                    'message': output.strip() or 'Le scan a échoué avant son enregistrement.'
                })

            if request_id:
                ScanRequest.objects.filter(id=request_id, user=request.user, status='approved').delete()

            scan = Scan.objects.select_related('machine', 'machine__owner').filter(
                machine__owner=request.user,
                id__gt=previous_scan_id
            ).order_by('-id').first()
            if not scan:
                scan = Scan.objects.select_related('machine', 'machine__owner').filter(machine__owner=request.user).order_by('-id').first()

            if not scan:
                return JsonResponse({
                    'status': 'error',
                    'message': "Le scan s'est terminé mais aucun enregistrement n'a été trouvé."
                })

            return JsonResponse({
                'status': 'ok',
                'output': output,
                'scan': _scan_result_payload(scan),
                'detail_url': f'/security/scan-detail/{scan.id}/',
                'history_url': '/security/scan-history/'
            })
        except subprocess.TimeoutExpired:
            return JsonResponse({'status': 'error', 'message': 'Le scan a pris trop de temps (120 secondes).'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    return JsonResponse({'status': 'error'}, status=405)

@login_required
def scan_history(request):
    if request.user.profile.role == 'analyst':
        scans = Scan.objects.select_related('machine', 'machine__owner').all().order_by('-date_scan')
    else:
        scans = Scan.objects.select_related('machine', 'machine__owner').filter(machine__owner=request.user).order_by('-date_scan')

    for scan in scans:
        try:
            resultat = json.loads(scan.resultat) if isinstance(scan.resultat, str) else (scan.resultat or {})
        except json.JSONDecodeError:
            resultat = {}

        scan.open_ports_count = sum(1 for port in resultat.get('ports', []) if port.get('status') == 'ouvert')
        scan.firewall_status = resultat.get('firewall', 'Non disponible')

    return render(request, 'scan_history.html', {'scans': scans})

@login_required
def delete_scan(request, scan_id):
    scan = get_object_or_404(Scan, id=scan_id)
    if request.user.profile.role == 'analyst' or scan.machine.owner == request.user:
        if request.method == 'POST':
            scan.delete()
            return redirect('dashboard')
        return render(request, 'delete_scan.html', {'scan': scan})
    return redirect('dashboard')

@login_required
def view_scan_detail(request, scan_id):
    scan = get_object_or_404(Scan, id=scan_id)
    if request.user.profile.role != 'analyst' and scan.machine.owner != request.user:
        return redirect('dashboard')
    
    if isinstance(scan.resultat, str):
        try:
            scan.resultat = json.loads(scan.resultat)
        except:
            scan.resultat = {}
    
    if not isinstance(scan.resultat, dict):
        scan.resultat = {}
    
    # Initialiser toutes les clés possibles
    if 'firewall' not in scan.resultat:
        scan.resultat['firewall'] = 'Non disponible'
    if 'sensitive_processes' not in scan.resultat:
        scan.resultat['sensitive_processes'] = []
    if 'active_ports' not in scan.resultat:
        scan.resultat['active_ports'] = []
    if 'ports' not in scan.resultat:
        scan.resultat['ports'] = []
    # Nouveaux scanners
    if 'vulnerable_software' not in scan.resultat:
        scan.resultat['vulnerable_software'] = []
    if 'critical_services' not in scan.resultat:
        scan.resultat['critical_services'] = []
    if 'admin_count' not in scan.resultat:
        scan.resultat['admin_count'] = 0
    if 'startup_services' not in scan.resultat:
        scan.resultat['startup_services'] = []
    if 'antivirus_detected' not in scan.resultat:
        scan.resultat['antivirus_detected'] = []
    
    return render(request, 'scan_detail.html', {'scan': scan})

# ==================== CRUD INCIDENTS ====================

@login_required
def incident_list(request):
    if request.user.profile.role == 'analyst':
        incidents = Incident.objects.all().order_by('-created_at')
    else:
        incidents = Incident.objects.filter(created_by=request.user).order_by('-created_at')
    return render(request, 'incident_list.html', {'incidents': incidents})

@login_required
def incident_create(request):
    if request.user.profile.role == 'analyst':
        form_class = IncidentAnalystForm
    else:
        form_class = IncidentUserForm
    
    if request.method == 'POST':
        form = form_class(request.POST)
        if form.is_valid():
            incident = form.save(commit=False)
            incident.created_by = request.user
            incident.save()
            return redirect('incident_list')
    else:
        form = form_class()
    return render(request, 'incident_form.html', {'form': form})

@login_required
def incident_update(request, pk):
    incident = get_object_or_404(Incident, pk=pk)
    
    if request.user.profile.role != 'analyst' and incident.created_by != request.user:
        return redirect('incident_list')
    
    if request.user.profile.role == 'analyst':
        form_class = IncidentAnalystForm
    else:
        form_class = IncidentUserForm
    
    if request.method == 'POST':
        form = form_class(request.POST, instance=incident)
        if form.is_valid():
            form.save()
            return redirect('incident_list')
    else:
        form = form_class(instance=incident)
    return render(request, 'incident_form.html', {'form': form})

@login_required
def incident_delete(request, pk):
    try:
        incident = Incident.objects.get(pk=pk)
    except Incident.DoesNotExist:
        return redirect('incident_list')
    
    if request.user.profile.role != 'analyst' and incident.created_by != request.user:
        return redirect('incident_list')
    
    if request.method == 'POST':
        incident.delete()
        return redirect('incident_list')
    
    return render(request, 'incident_confirm_delete.html', {'incident': incident})

# ==================== GET LAST SCAN ====================

@login_required
def get_last_scan(request):
    """Retourne le dernier scan de l'utilisateur au format JSON avec tous les détails (ports + nouveaux scanners)"""
    try:
        if request.user.profile.role == 'analyst':
            last_scan = Scan.objects.filter().order_by('-date_scan').first()
        else:
            last_scan = Scan.objects.filter(machine__owner=request.user).order_by('-date_scan').first()
        
        if last_scan:
            if isinstance(last_scan.resultat, str):
                try:
                    resultat = json.loads(last_scan.resultat)
                except:
                    resultat = {}
            else:
                resultat = last_scan.resultat or {}
            
            open_ports_count = 0
            for port in resultat.get('ports', []):
                if port.get('status') == 'ouvert':
                    open_ports_count += 1
            
            return JsonResponse({
                'status': 'ok',
                'scan': {
                    'id': last_scan.id,
                    'score': last_scan.score,
                    'firewall': resultat.get('firewall', 'Non disponible'),
                    'sensitive_processes': resultat.get('sensitive_processes', []),
                    'active_ports': resultat.get('active_ports', []),
                    'open_ports_count': open_ports_count,
                    'ports': resultat.get('ports', []),
                    # Nouveaux scanners
                    'vulnerable_software': resultat.get('vulnerable_software', []),
                    'critical_services': resultat.get('critical_services', []),
                    'admin_count': resultat.get('admin_count', 0),
                    'startup_services': resultat.get('startup_services', []),
                    'antivirus_detected': resultat.get('antivirus_detected', [])
                }
            })
        else:
            return JsonResponse({'status': 'error', 'message': 'Aucun scan trouvé'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

# ==================== ANALYST : GESTION DES UTILISATEURS (ARBORESCENCE) ====================

@login_required
def get_users_list(request):
    """Retourne la liste des utilisateurs (sauf analyst) au format JSON"""
    if request.user.profile.role != 'analyst':
        return JsonResponse({'status': 'error', 'message': 'Non autorisé'}, status=403)
    
    users = User.objects.filter(profile__role='user').values('id', 'username')
    return JsonResponse({'status': 'ok', 'users': list(users)})

@login_required
def get_user_machines(request, user_id):
    """Retourne la liste des machines d'un utilisateur au format JSON"""
    if request.user.profile.role != 'analyst':
        return JsonResponse({'status': 'error', 'message': 'Non autorisé'}, status=403)
    
    machines = Machine.objects.filter(owner_id=user_id).values('id', 'name', 'ip_address', 'os')
    return JsonResponse({'status': 'ok', 'machines': list(machines)})

@login_required
def get_machine_scans(request, machine_id):
    """Retourne la liste des scans d'une machine au format JSON"""
    if request.user.profile.role != 'analyst':
        return JsonResponse({'status': 'error', 'message': 'Non autorisé'}, status=403)
    
    scans = Scan.objects.filter(machine_id=machine_id).order_by('-date_scan').values('id', 'date_scan', 'score')
    # Convertir date_scan en string pour JSON
    for scan in scans:
        scan['date_scan'] = scan['date_scan'].strftime('%d/%m/%Y %H:%M')
    return JsonResponse({'status': 'ok', 'scans': list(scans)}) 
# ==================== PAGES D'AIDE ====================

@login_required
def help_score(request):
    """Page expliquant le calcul du score de sécurité"""
    return render(request, 'help_score.html')

@login_required
def help_elements(request):
    """Page expliquant chaque élément scanné"""
    return render(request, 'help_elements.html') 
