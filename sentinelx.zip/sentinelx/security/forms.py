from django import forms
from .models import Machine, Incident

class MachineForm(forms.ModelForm):
    class Meta:
        model = Machine
        fields = ['name', 'ip_address', 'os']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})

# Formulaire pour le User (client) : commentaire en lecture seule
class IncidentUserForm(forms.ModelForm):
    class Meta:
        model = Incident
        fields = ['title', 'description', 'status']
        help_texts = {
            'status': 'Statut de l\'incident (Ouvert, En cours, Résolu, Fermé)',
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})
        # Ajouter le champ commentaire en lecture seule pour l'affichage
        if self.instance and self.instance.pk:
            self.fields['commentaire_display'] = forms.CharField(
                label='Commentaire (lecture seule)',
                initial=self.instance.commentaire,
                required=False,
                widget=forms.Textarea(attrs={'readonly': 'readonly'})
            )

# Formulaire pour l'Analyst : tous les champs modifiables
class IncidentAnalystForm(forms.ModelForm):
    class Meta:
        model = Incident
        fields = ['title', 'description', 'commentaire', 'status', 'related_scan'] 

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})
