from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from security.models import Machine, ScanRequest, Scan, Incident
from accounts.models import Profile
import json

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'login.html', {'error': 'Identifiants invalides'})
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

def register_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']
        
        if password == password2:
            if not User.objects.filter(username=username).exists():
                user = User.objects.create_user(username=username, password=password)
                Profile.objects.create(user=user, role='user')
                return redirect('login')
            else:
                return render(request, 'register.html', {'error': 'Nom d\'utilisateur déjà pris'})
        else:
            return render(request, 'register.html', {'error': 'Les mots de passe ne correspondent pas'})
    
    return render(request, 'register.html')

@login_required
def dashboard_view(request):
    machines = Machine.objects.filter(owner=request.user)
    
    # Analyst voit tous les scans, User voit ses propres scans
    if hasattr(request.user, 'profile') and request.user.profile.role == 'analyst':
        scans = Scan.objects.all().order_by('-date_scan')
    else:
        scans = Scan.objects.filter(machine__owner=request.user).order_by('-date_scan')
    
    # Parser les résultats JSON des scans et compter les ports ouverts
    for scan in scans:
        if scan.resultat:
            if isinstance(scan.resultat, str):
                try:
                    scan.resultat = json.loads(scan.resultat)
                except:
                    scan.resultat = {}
            if not isinstance(scan.resultat, dict):
                scan.resultat = {}
            
            if 'firewall' not in scan.resultat:
                scan.resultat['firewall'] = 'Non disponible'
            if 'sensitive_processes' not in scan.resultat:
                scan.resultat['sensitive_processes'] = []
            if 'active_ports' not in scan.resultat:
                scan.resultat['active_ports'] = []
            if 'ports' not in scan.resultat:
                scan.resultat['ports'] = []
            
            # Compter les ports ouverts (ceux avec status "ouvert")
            open_ports_count = 0
            for port in scan.resultat.get('ports', []):
                if port.get('status') == 'ouvert':
                    open_ports_count += 1
            scan.open_ports_count = open_ports_count
    
    approved_requests = ScanRequest.objects.filter(user=request.user, status='approved')
    
    scan_requests = []
    if hasattr(request.user, 'profile') and request.user.profile.role == 'analyst':
        scan_requests = ScanRequest.objects.filter(status='pending')
        incidents_count = Incident.objects.count()
    else:
        incidents_count = Incident.objects.filter(created_by=request.user).count()
    
    return render(request, 'dashboard.html', {
        'machines': machines,
        'scans': scans,
        'scan_requests': scan_requests,
        'approved_requests': approved_requests,
        'incidents_count': incidents_count
    }) 
